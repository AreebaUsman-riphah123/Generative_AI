from flask import Flask, render_template, request
from groq import Groq
import traceback
from dotenv import load_dotenv
import os

# -------------------- Load environment variables --------------------
load_dotenv()

# Initialize Groq client with API key from .env
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# Initialize Flask app
app = Flask(__name__)

# -------------------- Routes --------------------
@app.route("/", methods=["GET", "POST"])
def index():
    ai_response = ""
    code = ""

    if request.method == "POST":
        code = request.form["code"]

        try:
            exec(code, {})
            ai_response = "✅ Code ran successfully. No errors detected."
        except Exception:
            error_trace = traceback.format_exc()
            ai_prompt = f"Analyze this Python error and suggest a fix:\n\n{error_trace}\n\nCode:\n{code}"

            ai_response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",  # ✅ updated model name
                messages=[{"role": "user", "content": ai_prompt}]
            ).choices[0].message.content

    return render_template("index.html", ai_response=ai_response, code=code)

# -------------------- Run app --------------------
if __name__ == "__main__":
    app.run(debug=True)
