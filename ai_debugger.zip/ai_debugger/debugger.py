import os
import traceback
from dotenv import load_dotenv
from openai import OpenAI
from rich.console import Console
from rich.panel import Panel

console = Console()
load_dotenv()

# Initialize Groq (OpenAI-style)
client = OpenAI(api_key=os.getenv("GROQ_API_KEY"), base_url="https://api.groq.com/openai/v1")

def ai_debugger(error_text, code_snippet=None):
    """Send error and code to AI for debugging help."""
    prompt = f"""
    You are an AI Debugger.
    Analyze the following Python error and code.
    Explain the cause clearly and suggest a fix.

    Error:
    {error_text}

    Code:
    {code_snippet if code_snippet else "(no code provided)"}
    """

    try:
        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",  # free on Groq
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        explanation = response.choices[0].message.content
        console.print(Panel(explanation, title="🧠 AI Debugger Suggestion", style="green"))
    except Exception as e:
        console.print(f"[red]Error contacting AI API:[/red] {e}")

def run_user_code(code_file):
    """Run user code and catch errors."""
    try:
        with open(code_file, "r") as f:
            code = f.read()
        exec(code, {})
    except Exception:
        error_info = traceback.format_exc()
        console.print(Panel(error_info, title="💥 Error Captured", style="red"))
        ai_debugger(error_info, code)

if __name__ == "__main__":
    target_file = input("Enter Python file to debug: ")
    run_user_code(target_file)
