document.getElementById("loginForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMsg = document.getElementById("errorMsg");

  errorMsg.textContent = "";

  // Basic frontend validation
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!email || !password) {
    errorMsg.textContent = "❌ Both fields are required.";
    return;
  }

  if (!emailPattern.test(email)) {
    errorMsg.textContent = "❌ Please enter a valid email address.";
    return;
  }

  try {
    // ✅ Send data to backend
    const response = await fetch("http://localhost:3000/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const result = await response.json();

    // ✅ Show backend validation result
    if (result.success) {
      alert("✅ Login Successful!");
      document.getElementById("loginForm").reset();
    } else {
      alert(result.message); // ❌ Invalid email or password popup
    }
  } catch (err) {
    alert("⚠️ Server not responding. Make sure backend is running!");
  }
});
