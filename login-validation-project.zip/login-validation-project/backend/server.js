// ✅ Import dependencies
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

// ✅ Create app
const app = express();
const PORT = 3000;

// ✅ Middleware
app.use(cors());
app.use(bodyParser.json());

// ✅ Dummy user data (you can change these)
const VALID_EMAIL = "test@example.com";
const VALID_PASSWORD = "12345";

// ✅ Login route
app.post("/login", (req, res) => {
  const { email, password } = req.body;

  // Check email and password
  if (email === VALID_EMAIL && password === VALID_PASSWORD) {
    res.json({ success: true, message: "Login successful!" });
  } else {
    res.json({ success: false, message: "❌ Invalid email or password!" });
  }
});

// ✅ Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
